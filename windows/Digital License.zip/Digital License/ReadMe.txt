====================================================================================================
   Digital License (HWID) Activation:
====================================================================================================

 - This activation is supported for Windows 10 only.
 - This activation does not store any files in the system.
 - Digital License (HWID) is a permanent activation for your system Hardware.
 - Once activated, then this activation can not be removed from the system.
 - Any important changes in the Hardware (such as motherboard) may deactivate the system. 
   Although it's possible to reactivate if your activation was linked to the Microsoft account.

 - For activation, the Windows Update Service and Internet connection must be enabled.
   If you are trying to activate without these conditions being met, then the system will auto-
   activate later when the conditions are met.

 - Auto activation scenario after the Windows reinstall:
   - Internet is required. (Only at the time of activation)
   - System will auto-activate if Retail (Consumer) media was used for the installation.
   - System will NOT auto-activate if VL (Business) media was used for the installation.
     In this case, user will have to insert that windows edition Retail/OEM key to activate, if
     user doesn't wish to activate again using this script.

 - Possible reasons of activation failure:
   - Internet is not connected.
   - Windows update service is disabled.
   - Use of a VPN, and/or a privacy-based hosts file, firewall rules.
   - Corrupt system files.
   - Microsoft servers block the activation request from some countries such as Iran.
   - Rarely, Microsoft activation server's problem.
   - Some other unknown (to me) reasons.

   * Troubleshoot guide is listed below.

====================================================================================================

   How it works?
   Is it safe?
   Is it possible that Microsoft can block these Digital Licenses (HWID)?
   
   https://pastebin.com/raw/7Xyaf15Z

====================================================================================================
   Supported Products:
====================================================================================================

   Windows 10:

   Core
   CoreCountrySpecific
   CoreN
   CoreSingleLanguage
   Education
   EducationN
   Enterprise
   EnterpriseN
   EnterpriseS    [LTSB 2015 & 2016]
   EnterpriseSN   [LTSB 2015 & 2016]
   Professional
   ProfessionalEducation
   ProfessionalEducationN
   ProfessionalN
   ProfessionalWorkstation
   ProfessionalWorkstationN
   ServerRdsh


   Note - Any Evaluation version of Windows (i.e. 'EVAL' LTSB/C) cannot be activated.
        - LTSC 2019 is not supported.

====================================================================================================
   Switches for the Script:
====================================================================================================

 - To run the script in unattended mode, use "/u" parameter. example,
Digital_License_Activation.cmd /u

   * Applies to MAS Separate Files version

====================================================================================================
   File Details:
====================================================================================================

 - File Details:

   73b54242dddf7770cdcaae9278fe1fb530ad5a63 *Files\gatherosstate.exe            Virus Total = 0/70
   430217b46c0a6fb5303ea347ca648e4d50880393 *Files\gatherosstateLTSB15.exe      Virus Total = 0/72
   ca4fb0a9cc09fffbb3205d9573d130e851bb1160 *Files\slc.dll                      Virus Total = 0/70
   2a18a87a2faabf5f783d38144cfb03e6ef295e1b *Files\gatherosstateLTSB15.txt      Virus Total = 0/58

   Virus Total Report Date: 08-05-2019

   * gatherosstateLTSB15.exe file is extracted from the gatherosstateLTSB15.txt, when required.

 - File Sources:

   - gatherosstate.exe (Original):
     From Windows 10 x86 17134 ADK

   - gatherosstateLTSB15.exe (Modified):
     Generated from @angelkyo's Open Source tool https://gitlab.com/angelkyo/w10-digitallicense

     This file is stored in gatherosstateLTSB15.txt with the help from the tool "Compressed2TXT"
     https://github.com/AveYo/Compressed2TXT
     It can be extracted by changing .txt extension to .cmd and and just run it.

   - slc.dll (Modified):

     Original slshim
     https://github.com/vyvojar/slshim

     New ideas and codes for the slc.dll by @sponpa
     Source Code https://tinyurl.com/y24dbdmw

     Further improvements for the slc.dll by @leitek8
     Source Code http://tinyurl.com/y2a98rlk

     How to compile slc.dll file?
     Download slc.7z Source Code file from the above @leitek8 post's link.
     Download mingw-w64,
     https://sourceforge.net/projects/mingw-w64/files/i686-8.1.0-release-win32-sjlj-rt_v6-rev0.7z
     Put source code folders in compiler folder in following way,
     mingw64\slcR
     mingw64\slcVL

     Run compile.cmd
     slc.dll = 64bit, slc32.dll (rename to slc.dll) 32bit
     slcR = For Digital License , slcVL = For KMS38

     Done.

====================================================================================================
   Manual Activation Process:
====================================================================================================

 - Prerequisite:

   Get the files, https://s.put.re/7WMz9vpF.7z     6cca81faa5b4c24e2e2fe66083e2b16f64ece321

   Make sure you have following files,  
   73b54242dddf7770cdcaae9278fe1fb530ad5a63 *gatherosstate.exe
   430217b46c0a6fb5303ea347ca648e4d50880393 *gatherosstateLTSB15.exe
   ca4fb0a9cc09fffbb3205d9573d130e851bb1160 *slc.dll

   * gatherosstateLTSB15.exe is only required in the LTSB 2015 activation.

   -------------------------------------------------------------------------------------------------

         Retail/OEM Keys            Windows 10 Editions

   YTMG3-N6DKC-DKB77-7M9GH-8HVX7    Core
   4CPRK-NM3K3-X6XXQ-RXX86-WXCHW    CoreN
   N2434-X9D7W-8PF6X-8DV9T-8TYMD    CoreCountrySpecific
   BT79Q-G7N6G-PGBYW-4YWX6-6F4BT    CoreSingleLanguage
   YNMGQ-8RYV3-4PGQ3-C8XTP-7CFBY    Education
   84NGF-MHBT6-FXBX8-QWJK7-DRR8H    EducationN
   XGVPP-NMH47-7TTHJ-W3FW7-8HV2C    Enterprise
   3V6Q6-NQXCX-V8YXR-9QCYV-QPFCT    EnterpriseN
   FWN7H-PF93Q-4GGP8-M8RF3-MDWWW    EnterpriseS      [LTSB 2015]
   8V8WN-3GXBH-2TCMG-XHRX3-9766K    EnterpriseSN     [LTSB 2015]
   NK96Y-D9CD8-W44CQ-R8YTK-DYJWX    EnterpriseS      [LTSB 2016]
   2DBW3-N2PJG-MVHW3-G7TDK-9HKR4    EnterpriseSN     [LTSB 2016]
   VK7JG-NPHTM-C97JM-9MPGT-3V66T    Professional
   2B87N-8KFHP-DKV6R-Y2C8J-PKCKT    ProfessionalN
   8PTT6-RNW4C-6V7J2-C2D3X-MHBPB    ProfessionalEducation
   GJTYN-HDMQY-FRR76-HVGC7-QPF8P    ProfessionalEducationN
   DXG7C-N36C4-C4HTG-X4T3X-2YV77    ProfessionalWorkstation
   WYPNQ-8C467-V2W6J-TX4WX-WT2RQ    ProfessionalWorkstationN
   NJCF7-PW8QT-3324D-688JX-2YV66    ServerRdsh

   -------------------------------------------------------------------------------------------------

 - Make sure the Windows Update Service and Internet are both enabled.
 - Open CMD as Admin, and enter following listed commands in the sequence in which they are given.
 - Enter Retail/OEM Key, (Replace '%key%' with the key from above list) with the following command:

slmgr.vbs /ipk %key%

 - Make sure slc.dll and gatherosstate.exe files are located in the same location.
 - Run gatherosstate.exe (If your Windows 10 edition is LTSB 2015 then run gatherosstateLTSB15.exe)
   After a few seconds GenuineTicket.xml file will appear. 
 - Copy GenuineTicket.xml to the root of c:\ Drive, and run the following command:

clipup -v -o -altto c:\

 - Activate Windows with the following command:

slmgr.vbs /ato

 - Check Activation Status with the following command:

slmgr.vbs /xpr

 - Done.

====================================================================================================
   Troubleshoot activation issues:
====================================================================================================

 - Make sure the Internet is connected.
 - Open a Command Prompt and type services.msc and hit Enter, When Services opens up, look for the 
   'Windows Update' and Make sure its startup type is set to Automatic.
 - VPN, privacy-based hosts and/or firewall rules may cause problems with the activation. Disable 
   them if you are facing problems in activation.
 - Reboot the system.
 - Now run the script to activate Windows 10, and if unsuccessful, 
   - Try the troubleshoot button in settings activation page.
     If still unsuccessful then read additional troubleshoot options listed below.

   - Open CMD as Admin, and enter the following command:

Dism /online /Cleanup-Image /RestoreHealth

   - After its done, reboot the system and Open CMD as Admin, and enter the following command:

sfc.exe /scannow

   - After its done, reboot the system and run the activation script, and if unsuccessful,
     Make sure hardware component proper drivers are installed, check manufacturer site/Windows-
     update for drivers.
   - After its done, reboot the system and run the activation script, and if unsuccessful,
     It's time to clean install the windows :D 

   -------------------------------------------
    Activation is blocked in some countries -
   -------------------------------------------

 - Microsoft servers block the activation request from some countries such as Iran,
   To activate the system in those countries, follow below steps,
   - In settings app, Change Region and Timezone to the USA location and use a VPN, choose the
     location from the USA. Now run the script, it should activate now.

====================================================================================================
   Credits:
====================================================================================================

   'Microsoft Activation Scripts' is just a fork of other honorable developers tools and script.

   The purpose of this script is to create an activator which is opensource and clean from antivirus
   detection. To achieve this I've used the following projects as the base of this script.  
   I would like to say thanks to the following authors for making such awesome projects.

----------------------------------------------------------------------------------------------------

---------------------
   Original Authors:
---------------------

   *Anonymous        Original Author of Digital License (HWID) Activation without
                     KMS or predecessor install/upgrade.

   @s1ave77          hwid.kms38.gen.mk6.exe
                     https://www.nsaneforums.com/topic/312871--/
                     P.S. @s1ave77 wrote this First frontend program based on the findings of above
                     mentioned *Anonymous Developer.

                     (*Forked it to make it batch script based open source and clean from av's 
                      detection)

   @vyvojar          slshim (slc.dll)
                     https://github.com/vyvojar/slshim/releases

   @abbodi1406       Check-Activation-Status.cmd
                     Check-Activation-Status-Alternative.cmd
                     https://forums.mydigitallife.net/posts/838808
                     (*Applied it as it is)

   @AveYo aka @BAU   Compressed2TXT
                     https://github.com/AveYo/Compressed2TXT
                     (For storing the files in text format)

   @Compo            Extract the text from batch script without character issue
                     https://forums.mydigitallife.net/posts/1221231/

---------------------
   Tweakers/Modders:
---------------------

   @sponpa           New ideas for the HWID/KM38 Generation
                     https://tinyurl.com/y24dbdmw

   @leitek8          Improvements for the slc.dll
                     http://tinyurl.com/y2a98rlk
                     (*Applied it as it is)

   @hwidmod          Gatherosstate mod to generate HWID in LTSB2015
                     https://tinyurl.com/y86za5zq

   @angelkyo         Open source code to create mod gatherosstateLTSB15.exe for LTSB2015
                     https://gitlab.com/angelkyo/w10-digitallicense
                     (*Applied MOD gatherosstate as it is)

   @WindowsAddict    Microsoft Activation Scripts
                     https://www.nsaneforums.com/topic/316668--/

---------------------
          Kind Help:
---------------------

   @RPO              Providing Great support in correction and improvements in this script

   @abbodi1406       Answering all of my queries.

   @BorrowedWifi     Fixing English grammar errors in the Read Me.

====================================================================================================
   Discussion / Error Report / Support / Feedback / etc:
====================================================================================================

 - Go to the homepage,
   Microsoft Activation Scripts https://www.nsaneforums.com/topic/316668--/
   
   Alternatively, email me
   windowsaddict@protonmail.com

====================================================================================================